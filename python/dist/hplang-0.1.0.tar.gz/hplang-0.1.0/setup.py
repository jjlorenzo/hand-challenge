# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['hplang']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['hpl = hplang.__main__:entry_point']}

setup_kwargs = {
    'name': 'hplang',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Command-Line Interface\n\n```sh\n$ cd python\n\n$ pip install dist/hplang-0.1.0.tar.gz\n\n$ hpl --help\nusage: hpl [-h] input\n\npositional arguments:\n  input\n\noptions:\n  -h, --help  show this help message and exit\n\n$ hpl ../input/input.hand\n```\n\n## Contribute\n\n```sh\n$ cd python\n\n$ poetry install\n\n$ poetry run ptw -- --testmon\n\n$ poetry run hpl ../input/input.hand\n```\n',
    'author': 'jjlorenzo',
    'author_email': 'jjlorenzo@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
